You can now help ScribeJava not only by Pull Requests.

You can use [https://paypal.me/kullfar](https://paypal.me/kullfar) directly

or try donation button from PayPal: [![Donate with PayPal button](https://www.paypalobjects.com/en_US/RU/i/btn/btn_donateCC_LG.gif)](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=E3XAUM2ET2R3Y&source=url)

Thanks in advance!

ps.If you can't for any reason use above methods, let me know, we will find the way out.

Hall of fame "Donors" (in alphabetical order, if you don't want to be here, just put a note along with the donation):<br/>
1.Douglas Ross from USA<br/>
2.Your name can be here.
