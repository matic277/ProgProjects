package com.github.scribejava.core.builder.api;

public enum OAuth1SignatureType {

    HEADER,
    QUERY_STRING
}
