package com.github.scribejava.core.httpclient;

public interface HttpClientConfig {

    HttpClientConfig createDefaultConfig();
}
